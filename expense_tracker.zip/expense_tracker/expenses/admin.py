from django.contrib import admin
from expenses.models import Expense, Income

# Register your models here.
admin.site.register(Income)  # Register the Income model
admin.site.register(Expense)  # Register the Expense model
