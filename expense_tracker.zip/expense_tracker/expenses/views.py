from django.shortcuts import render, redirect
from .models import Income, Expense
from .forms import IncomeForm, ExpenseForm
from io import BytesIO
import matplotlib.pyplot as plt
import base64
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
@login_required
def index(request):
    # Get all income and expense objects
    incomes = Income.objects.all()
    expenses = Expense.objects.all()

    # Calculate current balance
    balance = sum(income.amount for income in incomes) - sum(expense.amount for expense in expenses)

    # Handle form submissions for adding income or expense
    if request.method == 'POST':
        if 'income-submit' in request.POST:
            income_form = IncomeForm(request.POST)
            expense_form = ExpenseForm()
            if income_form.is_valid():
                income_form.save()
                return redirect('index')
        elif 'expense-submit' in request.POST:
            expense_form = ExpenseForm(request.POST)
            income_form = IncomeForm()
            if expense_form.is_valid():
                expense_form.save()
                return redirect('index')
    else:
        income_form = IncomeForm()
        expense_form = ExpenseForm()

    context = {
        'incomes': incomes,
        'expenses': expenses,
        'balance': balance,
        'income_form': income_form,
        'expense_form': expense_form,
    }

    return render(request, 'expenses/index.html', context)

def summary(request):
    # Get all income and expense objects
    incomes = Income.objects.all()
    expenses = Expense.objects.all()

    # Calculate total income and total expense
    total_income = sum(income.amount for income in incomes)
    total_expense = sum(expense.amount for expense in expenses)

    # Generate pie chart to show total income vs total expenses
    labels = ['Total Income', 'Total Expenses']
    sizes = [total_income, total_expense]
    colors = ['#28a745', '#dc3545']
    explode = (0.1, 0)  # Slight separation for the first slice

    # Create and save pie chart
    plt.figure(figsize=(6, 6))
    plt.pie(sizes, labels=labels, colors=colors, explode=explode,
            autopct='%1.1f%%', startangle=90, shadow=True)
    plt.axis('equal')  # Ensures the pie is a circle

    # Save the chart to a buffer
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
    buffer.close()

    context = {
        'incomes': incomes,
        'expenses': expenses,
        'chart': image_base64
    }

    return render(request, 'expenses/summary.html', context)

def register_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']

        if password != confirm_password:
            messages.error(request, 'Passwords do not match.')
            return redirect('register')

        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists.')
            return redirect('register')

        user = User.objects.create_user(username=username, password=password)
        user.save()
        messages.success(request, 'Registration successful. Please log in.')
        return redirect('login')

    return render(request, 'expenses/register.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('index')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'expenses/login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

def user_logout(request):
    logout(request)  # Logs out the user
    return redirect('login')