from django.db import models
from django.contrib.auth.models import User

# Transaction Types for Income and Expense
class TransactionType(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return self.name

# Income Model with Category and Transaction Type
class Income(models.Model):
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateField()
    description = models.CharField(max_length=200, blank=True, null=True)
    transaction_type = models.ForeignKey(TransactionType, on_delete=models.SET_NULL, null=True, blank=True)
    category = models.CharField(max_length=100, blank=True, null=True)  # Category for income (e.g., Salary, Gift, etc.)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)  # Link each income to a user

    def __str__(self):
        return f"Income: {self.amount} on {self.date}"

# Expense Model with Category and Transaction Type
class Expense(models.Model):
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateField()
    description = models.CharField(max_length=200, blank=True, null=True)
    transaction_type = models.ForeignKey(TransactionType, on_delete=models.SET_NULL, null=True, blank=True)
    category = models.CharField(max_length=100, blank=True, null=True)  # Category for expense (e.g., Rent, Groceries, etc.)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)  # Link each expense to a user

    def __str__(self):
        return f"Expense: {self.amount} on {self.date}"

# Transaction model (for linking both incomes and expenses)
class Transaction(models.Model):
    TRANSACTION_CHOICES = [
        ('INCOME', 'Income'),
        ('EXPENSE', 'Expense'),
    ]
    transaction_type = models.CharField(max_length=10, choices=TRANSACTION_CHOICES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateField()
    description = models.CharField(max_length=200, blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    category = models.CharField(max_length=100, blank=True, null=True)  # Category for the transaction
    transaction_detail = models.TextField(blank=True, null=True)  # More detailed information about the transaction

    def __str__(self):
        return f"{self.transaction_type} of {self.amount} on {self.date}"
